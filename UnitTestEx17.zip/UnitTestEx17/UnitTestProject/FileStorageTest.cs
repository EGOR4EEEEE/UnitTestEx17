﻿using NUnit.Framework;
using System;
using System.Reflection;
using UnitTestEx;
using Assert = NUnit.Framework.Assert;

namespace UnitTestProject
{
    /// <summary>
    /// Summary description for FileStorageTest
    /// </summary>
    [TestFixture] // Используем только NUnit
    public class FileStorageTest
    {
        public const string MAX_SIZE_EXCEPTION = "DIFFERENT MAX SIZE";
        public const string NULL_FILE_EXCEPTION = "NULL FILE";
        public const string NO_EXPECTED_EXCEPTION_EXCEPTION = "There is no expected exception";

        public const string SPACE_STRING = " ";
        public const string FILE_PATH_STRING = "@D:\\JDK-intellij-downloader-info.txt";
        public const string CONTENT_STRING = "Some text";
        public const string REPEATED_STRING = "AA";
        public const string WRONG_SIZE_CONTENT_STRING = "TEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtextTEXTtext";
        public const string TIC_TOC_TOE_STRING = "tictoctoe.game";

        public const int NEW_SIZE = 5;

        //public FileStorage storage;
        public UnitTestEx.FileStorage storage;

        [SetUp]
        public void Setup()
        {
            //storage = new FileStorage(NEW_SIZE);
            storage = new UnitTestEx.FileStorage(NEW_SIZE);
        }

        /* НАБОРЫ ДАННЫХ */

        static object[] ValidFilesForWrite =
        {
            new object[] { new File(REPEATED_STRING, CONTENT_STRING) },
            new object[] { new File(FILE_PATH_STRING, CONTENT_STRING) }
        };

        static object[] NewFilesData =
        {
            new object[] { new File(REPEATED_STRING, CONTENT_STRING) },
            new object[] { new File(SPACE_STRING, WRONG_SIZE_CONTENT_STRING) },
            new object[] { new File(FILE_PATH_STRING, CONTENT_STRING) }
        };

        static object[] FilesForDeleteData =
        {
            new object[] { new File(REPEATED_STRING, CONTENT_STRING), REPEATED_STRING },
            new object[] { null, TIC_TOC_TOE_STRING }
        };

        static object[] NewExceptionFileData = {
            new object[] { new File(REPEATED_STRING, CONTENT_STRING) }
        };

        /* Проверка процедуры записи файла */
        [Test, TestCaseSource(nameof(NewFilesData))]
        public void WriteTest(File file)
        {
            if (file.GetSize() >= NEW_SIZE)
            {
                // Размер превышает лимит — метод должен вернуть false
                Assert.That(storage.Write(file), Is.False);
            }
            else
            {
                // Размер допустим — ожидание успешной записи
                Assert.That(storage.Write(file), Is.True);
            }
            storage.DeleteAllFiles();
        }

        /* Проверка записи файла с повторяющимся именем */
        [Test, TestCaseSource(nameof(NewExceptionFileData))]
        public void WriteExceptionTest(File file)
        {
            bool isException = false;
            try
            {
                storage.Write(file);
                storage.Write(file); // Повторная попытка записи
            }
            catch (FileNameAlreadyExistsException)
            {
                isException = true;
            }
            Assert.That(isException, Is.True, NO_EXPECTED_EXCEPTION_EXCEPTION);
            storage.DeleteAllFiles();
        }

        /* Проверка метода наличия файла */
        [Test, TestCaseSource(nameof(ValidFilesForWrite))]
        public void IsExistsTest(File file)
        {
            string name = file.GetFilename();
            // До сохранения файл должен отсутствовать
            Assert.That(storage.IsExists(name), Is.False);
            // Пытаемся сохранить файл
            bool isWritten = false;
            try
            {
                isWritten = storage.Write(file);
            }
            catch (FileNameAlreadyExistsException e)
            {
                Console.WriteLine($"Exception {e} in method {MethodBase.GetCurrentMethod().Name}");
            }

            // Если не удалось записать — дальнейшая проверка не имеет смысла
            Assert.That(isWritten, Is.True, $"Файл '{name}' не был записан, проверка невозможна");

            // После записи файл должен быть найден
            Assert.That(storage.IsExists(name), Is.True);

            storage.DeleteAllFiles();
        }

        /* Проверка функциональности удаления файла */
        [Test, TestCaseSource(nameof(FilesForDeleteData))]
        public void DeleteTest(File file, String fileName)
        {
            if (file != null)
            {
                storage.Write(file);
                // Удаление существующего файла — ожидаем true
                Assert.That(storage.Delete(fileName), Is.True);
                // Повторное удаление — файл уже отсутствует, должно быть false
                Assert.That(storage.Delete(fileName), Is.False);
            }
            else
            {
                // Попытка удалить несуществующий/null файл
                Assert.That(storage.Delete(fileName), Is.False);
            }
        }

        /* Проверка метода получения списка файлов */
        [Test]
        public void GetFilesTest()
        {
            storage.Write(new File("test1.txt", "abc"));
            storage.Write(new File("test2.txt", "def"));

            var files = storage.GetFiles();

            Assert.That(files, Is.Not.Null);
            Assert.That(files.Count, Is.GreaterThan(0));

            foreach (File file in files)
            {
                Assert.That(file, Is.Not.Null);
            }
        }

        /* Проверка получения конкретного файла по имени */
        [Test, TestCaseSource(nameof(ValidFilesForWrite))]
        public void GetFileTest(File expectedFile)
        {
            bool isWritten = storage.Write(expectedFile);
            // При неудачной записи — дальнейшие действия бессмысленны
            Assert.That(isWritten, Is.True, $"Файл '{expectedFile.GetFilename()}' не был записан");

            File actualFile = storage.GetFile(expectedFile.GetFilename());

            bool sameFilename = actualFile.GetFilename().Equals(expectedFile.GetFilename());
            bool sameSize = actualFile.GetSize().Equals(expectedFile.GetSize());

            Assert.That(sameFilename && sameSize, Is.True,
                $"There are differences in filename or size for file '{expectedFile.GetFilename()}'");
            storage.DeleteAllFiles();
        }

        //Мои тесты
        [Test]//Проверяет, что после записи нескольких файлов общее оставшееся место корректно учитывается
        public void PartialStorageUsageTest()
        {
            // Размер хранилища = 5
            var file1 = new File("a.txt", "1"); // размер = 1
            var file2 = new File("b.txt", "22"); // размер = 2
            var file3 = new File("c.txt", "333"); // размер = 3 — не влезет

            bool result1 = storage.Write(file1);
            bool result2 = storage.Write(file2);
            bool result3 = storage.Write(file3); // места уже нет

            Assert.That(result1, Is.True);
            Assert.That(result2, Is.True);
            Assert.That(result3, Is.False, "Файл не должен влезть в оставшееся пространство");

            storage.DeleteAllFiles();
        }


        [Test]//Проверка, что нельзя записать файл с тем же именем, даже если содержимое отличается
        public void WriteFileWithSameNameDifferentContentTest()
        {
            var file1 = new File("duplicate.txt", "content1");
            var file2 = new File("duplicate.txt", "different content");

            storage.Write(file1);

            bool isExceptionThrown = false;
            try
            {
                storage.Write(file2);
            }
            catch (FileNameAlreadyExistsException)
            {
                isExceptionThrown = true;
            }

            Assert.That(isExceptionThrown, Is.True, "Ожидалось исключение при записи файла с тем же именем");
            storage.DeleteAllFiles();
        }


        [Test]//Проверка, можно ли записать файл с пустым именем
        public void WriteFileWithEmptyNameTest()
        {
            var emptyNameFile = new File("", "some content");

            bool result = storage.Write(emptyNameFile);

            Assert.That(result, Is.True.Or.False, "Поведение должно быть определено — разрешается ли файл с пустым именем?");
            storage.DeleteAllFiles();
        }

    }
}
